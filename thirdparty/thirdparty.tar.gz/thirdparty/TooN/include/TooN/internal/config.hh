/* internal/config.hh.  Generated from config.hh.in by configure.  */
/* #undef TOON_TYPEOF_DECLTYPE */

/* #undef TOON_TYPEOF_TYPEOF */

#define TOON_TYPEOF___TYPEOF__ 1

/* #undef TOON_TYPEOF_BOOST */

/* #undef TOON_TYPEOF_BUILTIN */

#define TOON_DEPRECATED_GCC 1 

#define TOON_USE_LAPACK 1

/* #undef TOON_DEFAULT_PRECISION */
